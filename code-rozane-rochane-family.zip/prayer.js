// Calcul des horaires de prière (algorithme astronomique type PrayTimes) — hors connexion
const PrayerCalc = (() => {
  const d2r = d => d * Math.PI / 180, r2d = r => r * 180 / Math.PI;
  const sin = d => Math.sin(d2r(d)), cos = d => Math.cos(d2r(d)), tan = d => Math.tan(d2r(d));
  const asin = x => r2d(Math.asin(x)), acos = x => r2d(Math.acos(x));
  const atan2 = (y, x) => r2d(Math.atan2(y, x)), acot = x => r2d(Math.atan(1 / x));
  const fix = (a, b) => { a = a - b * Math.floor(a / b); return a < 0 ? a + b : a; };
  const fixA = a => fix(a, 360), fixH = a => fix(a, 24);

  const METHODS = {
    uoif: { name: 'UOIF France (12° / 12°)', fajr: 12, isha: 12 },
    isna: { name: 'Angle 15° / 15°', fajr: 15, isha: 15 },
    mwl: { name: 'Ligue islamique mondiale (18° / 17°)', fajr: 18, isha: 17 },
    a18: { name: 'Angle 18° / 18°', fajr: 18, isha: 18 }
  };

  function julian(y, m, d) {
    if (m <= 2) { y -= 1; m += 12; }
    const A = Math.floor(y / 100), B = 2 - A + Math.floor(A / 4);
    return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + B - 1524.5;
  }
  function sunPos(jd) {
    const D = jd - 2451545.0;
    const g = fixA(357.529 + 0.98560028 * D);
    const q = fixA(280.459 + 0.98564736 * D);
    const L = fixA(q + 1.915 * sin(g) + 0.020 * sin(2 * g));
    const e = 23.439 - 0.00000036 * D;
    const RA = atan2(cos(e) * sin(L), cos(L)) / 15;
    return { decl: asin(sin(e) * sin(L)), eqt: q / 15 - fixH(RA) };
  }

  // Renvoie les heures décimales locales
  function compute(y, m, d, lat, lng, tz, opt) {
    const jd = julian(y, m, d) - lng / (15 * 24);
    const midDay = t => fixH(12 - sunPos(jd + t).eqt);
    const angleTime = (angle, t, ccw) => {
      const decl = sunPos(jd + t).decl, noon = midDay(t);
      let v = (-sin(angle) - sin(decl) * sin(lat)) / (cos(decl) * cos(lat));
      v = Math.max(-1, Math.min(1, v));
      const T = acos(v) / 15;
      return noon + (ccw ? -T : T);
    };
    const asrTime = (f, t) => {
      const decl = sunPos(jd + t).decl;
      return angleTime(-acot(f + tan(Math.abs(lat - decl))), t);
    };
    let t = { fajr: 5, sunrise: 6, dhuhr: 12, asr: 13, sunset: 18, isha: 18 };
    for (let i = 0; i < 2; i++) {
      const p = {}; for (const k in t) p[k] = t[k] / 24;
      t = {
        fajr: angleTime(opt.fajr, p.fajr, true),
        sunrise: angleTime(0.833, p.sunrise, true),
        dhuhr: midDay(p.dhuhr),
        asr: asrTime(opt.asr || 1, p.asr),
        sunset: angleTime(0.833, p.sunset),
        isha: angleTime(opt.isha, p.isha)
      };
    }
    for (const k in t) t[k] += tz - lng / 15;
    t.maghrib = t.sunset;
    return t;
  }

  function tzOffset(y, m, d) { return -new Date(y, m - 1, d, 12).getTimezoneOffset() / 60; }
  function toHM(h) {
    let mins = Math.round(h * 60);
    mins = ((mins % 1440) + 1440) % 1440;
    return String(Math.floor(mins / 60)).padStart(2, '0') + ':' + String(mins % 60).padStart(2, '0');
  }
  function addMin(hm, n) {
    const [a, b] = hm.split(':').map(Number);
    let t = a * 60 + b + n; t = ((t % 1440) + 1440) % 1440;
    return String(Math.floor(t / 60)).padStart(2, '0') + ':' + String(t % 60).padStart(2, '0');
  }

  // date: 'YYYY-MM-DD' ; cfg: {lat,lng,method,asr,adj:{fajr..isha}}
  function forDate(date, cfg) {
    const [y, m, d] = date.split('-').map(Number);
    const meth = METHODS[cfg.method] || METHODS.uoif;
    const t = compute(y, m, d, cfg.lat, cfg.lng, tzOffset(y, m, d), { fajr: meth.fajr, isha: meth.isha, asr: cfg.asr === 'hanafi' ? 2 : 1 });
    const adj = cfg.adj || {};
    const out = {};
    for (const k of ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha']) out[k] = addMin(toHM(t[k]), Number(adj[k] || 0));
    return out;
  }
  return { forDate, METHODS, compute };
})();
if (typeof module !== 'undefined') module.exports = PrayerCalc;
